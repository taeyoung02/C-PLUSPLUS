#include<stdio.h>
int main() {
	int a[] = { 11,2,3,4,5 };
	printf("%d\n",a);
	int *b = a;
	printf("%d %d %d %d %d", b, *b,b[1],&a,a);
	bool truth = &a;
	bool truth_2 = a;
	if (truth = truth_2) {
		printf("����");
	}
	else printf("�ٸ���");
	
	if (a[-2232] = *a)printf("����");
	else printf("����");
}
/*
   *b=a[0]
   a = int a[] 
*/
