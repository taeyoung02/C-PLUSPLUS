#include<stdio.h>
int main() {
	int a[] = { 11,2,3,4,5 };
	int i;
	for (i = 0; i < 5; i++) {
		printf("%d\n", &a[i]);
		}
	int *b = a;
	int **c = &b;
	printf("%d %d %d %d %d %d %d", *b, **c, &b, a[2], &a, *c[0],b[0]);
	printf("\n");
	int r=3;
	int *q = &r;
	int **p = &q;
	printf("%d %d %d %d %d %d %d", *q, **p, &q, a[3], &r, *p, q);
	/*
	int *blah = &what;
	blah = &what;
	what = *blah
	*/
	/*
	int a = 5;
	int *ptr;
	ptr = &a;
	print("%d", ptr) -> ptr �� ����Ȱ� = a�� �ּҰ�
	*ptr = ptr�� ����Ű�� ������ ��
	*/

}