#include<stdio.h>
int main() {
	int arr[] = { 1,5,34,5,2,3,2,14,1,2,3 };
	for (int i = 1; i<sizeof(arr) / sizeof(int);i++)
	printf("%d",arr[i]);
}