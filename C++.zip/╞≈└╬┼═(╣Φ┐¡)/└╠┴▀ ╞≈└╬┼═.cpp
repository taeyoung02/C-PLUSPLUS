#include<stdio.h>
int main() {

	int a = 10;

	int *ptr;
	ptr = &a;
	int **ptr_ptr;
	ptr_ptr = &ptr;

	printf("*ptr =%d  ptr = %d a = %d &a= %d\n", *ptr, ptr, a, &a);
	*ptr = 20;
	printf("*ptr =%d  ptr = %d a = %d &a= %d\n\n", *ptr, ptr, a, &a);
	//�ּҰ��� �״��, ���� �ٲ�



	printf("**ptr_ptr=%d, *ptr_ptr=%d. ptr_ptr=%d\n", **ptr_ptr, *ptr_ptr, ptr_ptr);
	printf("&ptr=%d", &ptr);
}// **ptr_ptr = *ptr = a
 // *ptr_ptr = ptr = &a
 // ptr_ptr = &a
	

