#include<stdio.h>
int main() {
	int arr[1000];
	int n;
	scanf_s("%d", &n);
	for (int i = 0; i < n; i++)
		scanf_s("%d",&arr[i]);
	for (int j = n - 1; j>= 0; j--)
		printf("%d ", arr[j]);

}