#include<stdio.h>
int main() {/*
			1       
			123     
			12345
			1234567

			*/
	int k;
	scanf_s("%d", &k);
	for (int i = 1; i <= 2*k-1; i+=2)
	{
		for (int j = 1; j <=  i ; j++)
		{
			printf("%d ", j);
		}printf("\n");
	}
}